_tblErrorMessages = {};
_tblErrorMessages[0]=[[Success.]];
_tblErrorMessages[1000]=[[The specified file could not be found.]];
_tblErrorMessages[1001]=[[Failed to load file.]];
_tblErrorMessages[1002]=[[The specified path was not found.]];
_tblErrorMessages[1003]=[[The .exe file is invalid (non-Win32 .exe or error in .exe image).]];
_tblErrorMessages[1004]=[[The operating system denied access to the specified file.]];
_tblErrorMessages[1005]=[[The file name association is incomplete or invalid.]];
_tblErrorMessages[1006]=[[The DDE transaction could not be completed because other DDE transactions were being processed.]];
_tblErrorMessages[1007]=[[The DDE transaction failed.]];
_tblErrorMessages[1008]=[[The DDE transaction could not be completed because the request timed out.]];
_tblErrorMessages[1009]=[[The specified dynamic-link library was not found.]];
_tblErrorMessages[1011]=[[There is no application associated with the given file name extension. This error will also be returned if you attempt to print a file that is not printable.]];
_tblErrorMessages[1012]=[[There was not enough memory to complete the operation.]];
_tblErrorMessages[1013]=[[File execution failed.]];
_tblErrorMessages[1014]=[[A sharing violation occurred.]];
_tblErrorMessages[1015]=[[Could not determine viewer class name.]];
_tblErrorMessages[1016]=[[Could not determine viewer command line.]];
_tblErrorMessages[1017]=[[Associated viewer was not an executable file.]];
_tblErrorMessages[1018]=[[Associated viewer executable does not exist.]];
_tblErrorMessages[1019]=[[Invalid source specified.]];
_tblErrorMessages[1020]=[[Invalid destination specified.]];
_tblErrorMessages[1021]=[[Source file(s) does not exist.]];
_tblErrorMessages[1022]=[[Destination directory does not exist.]];
_tblErrorMessages[1023]=[[Failed to copy one or more files.]];
_tblErrorMessages[1024]=[[Failed to delete one or more files.]];
_tblErrorMessages[1025]=[[Failed to schedule delete on reboot.]];
_tblErrorMessages[1026]=[[Failed to schedule move on reboot.]];
_tblErrorMessages[1027]=[[Operation aborted by user.]];
_tblErrorMessages[1028]=[[An error occurred while calling the callback function.]];
_tblErrorMessages[1029]=[[Error, the callback function could not be found.]];
_tblErrorMessages[1030]=[[Could not get the size of the version information.]];
_tblErrorMessages[1031]=[[Could not get the file version information.]];
_tblErrorMessages[1032]=[[The specified filename contains invalid characters.]];
_tblErrorMessages[1033]=[[The destination file already exists.]];
_tblErrorMessages[1034]=[[An unknown error occurred.]];
_tblErrorMessages[1035]=[[Run on reboot command failed, could not open key.]];
_tblErrorMessages[1036]=[[Run on reboot command failed, could not set value.]];
_tblErrorMessages[1037]=[[Could not set the file's attributes.]];
_tblErrorMessages[1038]=[[Could not set file's compressed attribute.]];
_tblErrorMessages[1039]=[[Could not create destination Folder.]];
_tblErrorMessages[1040]=[[Could not create a backup of one or more files.]];
_tblErrorMessages[1041]=[[Out of memory.]];
_tblErrorMessages[1045]=[[File execution failed, elevation required.]];
_tblErrorMessages[1100]=[[The specified object could not be found.]];
_tblErrorMessages[1101]=[[Play command failed.]];
_tblErrorMessages[1102]=[[Pause command failed.]];
_tblErrorMessages[1103]=[[Media does not support seeking.]];
_tblErrorMessages[1104]=[[Seek command failed.]];
_tblErrorMessages[1105]=[[Stop command failed.]];
_tblErrorMessages[1106]=[[Could not display dialog.]];
_tblErrorMessages[1107]=[[File is too large to read.]];
_tblErrorMessages[1108]=[[The specified file could not be opened]];
_tblErrorMessages[1109]=[[The image file could not be found]];
_tblErrorMessages[1110]=[[Could not determine the size of the media.]];
_tblErrorMessages[1115]=[[Exception thrown by internal control.]];
_tblErrorMessages[1118]=[[Action cannot be performed on disabled object.]];
_tblErrorMessages[1120]=[[Failed to create object, an object with that name already exists.]];
_tblErrorMessages[1123]=[[Failed to create object, invalid object type.]];
_tblErrorMessages[1126]=[[Failed to create object.]];
_tblErrorMessages[1128]=[[The specified event could not be found.]];
_tblErrorMessages[1130]=[[Invalid zorder position value.]];
_tblErrorMessages[1140]=[[Error plugin version not supported.]];
_tblErrorMessages[1200]=[[The specified channel is out of range.]];
_tblErrorMessages[1201]=[[Audio channel is not loaded.]];
_tblErrorMessages[1202]=[[Set volume command failed.]];
_tblErrorMessages[1203]=[[Could not determine volume level.]];
_tblErrorMessages[1204]=[[Error CHANNEL_ALL not supported for the Audio.Load action.]];
_tblErrorMessages[1205]=[[Error CHANNEL_ALL not supported for the Audio.GetVolume action.]];
_tblErrorMessages[1206]=[[Error CHANNEL_ALL not supported for the Audio.GetCurrentPos action.]];
_tblErrorMessages[1207]=[[Error CHANNEL_ALL not supported for the Audio.Seek action.]];
_tblErrorMessages[1208]=[[Could not determine audio file's length.]];
_tblErrorMessages[1209]=[[Could not determine the playback position.]];
_tblErrorMessages[1210]=[[Error CHANNEL_ALL not supported for the Audio.GetOggTags action.]];
_tblErrorMessages[1211]=[[Error sound system not initialized.]];
_tblErrorMessages[1212]=[[Error file does not appear to be of type Ogg-Vorbis]];
_tblErrorMessages[1300]=[[The specified page does not exist.]];
_tblErrorMessages[1301]=[[Could not resolve the current page.]];
_tblErrorMessages[1302]=[[Error no radiobutton in specified group.]];
_tblErrorMessages[1303]=[[Error, cannot navigate pages while a dialog is visible.]];
_tblErrorMessages[1400]=[[Could not show status dialog.]];
_tblErrorMessages[1401]=[[Could not hide status dialog.]];
_tblErrorMessages[1402]=[[Could not set the status text on the status dialog.]];
_tblErrorMessages[1403]=[[Could not set the progress meter's range on the status dialog.]];
_tblErrorMessages[1404]=[[Could not set the progress meter's position on the status dialog.]];
_tblErrorMessages[1405]=[[Could not set the message text on the status dialog.]];
_tblErrorMessages[1406]=[[Could not set the title text on the status dialog.]];
_tblErrorMessages[1407]=[[Could not get the position of the progress meter.]];
_tblErrorMessages[1500]=[[Could not delete the specified INI file section.]];
_tblErrorMessages[1501]=[[Could not delete the specified INI file value.]];
_tblErrorMessages[1502]=[[Could not set the specified value.]];
_tblErrorMessages[1600]=[[Could not create the specified Registry key.]];
_tblErrorMessages[1601]=[[Could not delete the specified Registry key.]];
_tblErrorMessages[1602]=[[Could not delete the specified Registry value.]];
_tblErrorMessages[1603]=[[The specified sub key does not exist.]];
_tblErrorMessages[1604]=[[Could not get the sub key names.]];
_tblErrorMessages[1605]=[[Could not get the specified value's data.]];
_tblErrorMessages[1606]=[[Could not get the value names.]];
_tblErrorMessages[1607]=[[Could not get the registry value's type.]];
_tblErrorMessages[1608]=[[Could not set the specified registry value's data.]];
_tblErrorMessages[1700]=[[Could not add item to ListBox object.]];
_tblErrorMessages[1701]=[[Could not insert item into ListBox object.]];
_tblErrorMessages[1702]=[[Index out of range]];
_tblErrorMessages[1703]=[[Invalid list box type.]];
_tblErrorMessages[1704]=[[Invalid value for item checkbox.]];
_tblErrorMessages[1800]=[[Could not get the OS Version information.]];
_tblErrorMessages[1801]=[[Could not reboot system. OS information not available.]];
_tblErrorMessages[1802]=[[Failure in LoadLibrary().]];
_tblErrorMessages[1803]=[[GetProcAddress failed.]];
_tblErrorMessages[1804]=[[Failure code returned by DllRegisterServer.]];
_tblErrorMessages[1805]=[[Error in call to LoadTypeLib.]];
_tblErrorMessages[1806]=[[Error in call to RegisterTypeLib.]];
_tblErrorMessages[1807]=[[Error, font name cannot be empty.]];
_tblErrorMessages[1808]=[[Invalid font name.]];
_tblErrorMessages[1809]=[[Failed to add font to system font table.]];
_tblErrorMessages[1810]=[[Failed to add font to registry.]];
_tblErrorMessages[1811]=[[Failed to remove font from system font table.]];
_tblErrorMessages[1812]=[[Failed to remove font from registry.]];
_tblErrorMessages[1813]=[[Could not retrieve user information.]];
_tblErrorMessages[1814]=[[Unknown date format specified.]];
_tblErrorMessages[1815]=[[Unknown time format specified.]];
_tblErrorMessages[1816]=[[Unable to determine default language ID.]];
_tblErrorMessages[1817]=[[Unable to determine display info.]];
_tblErrorMessages[1818]=[[The server was unable to complete the registration of all the type libraries used by its classes.]];
_tblErrorMessages[1819]=[[The server was unable to complete the registration of all the object classes.]];
_tblErrorMessages[1820]=[[The server was unable to remove the entries of all the type libraries used by its classes.]];
_tblErrorMessages[1821]=[[The server was unable to remove the entries of all the object classes.]];
_tblErrorMessages[1822]=[[Failure code returned by DllUnregisterServer.]];
_tblErrorMessages[1823]=[[Could not reboot system.]];
_tblErrorMessages[1824]=[[Error, cannot use system restore while running in safe mode.]];
_tblErrorMessages[1825]=[[Error, the disk is full and system restore has been put into standby.]];
_tblErrorMessages[1826]=[[Error, the pending file rename operation already exists.]];
_tblErrorMessages[1827]=[[An internal error has occurred.]];
_tblErrorMessages[1828]=[[Error invalid sequence number.]];
_tblErrorMessages[1829]=[[The system restore service is disabled.]];
_tblErrorMessages[1830]=[[Error, the system restore operation has timed out.]];
_tblErrorMessages[1831]=[[Failed to access the number of running processes.]];
_tblErrorMessages[1832]=[[Failed to enumerate the processes.]];
_tblErrorMessages[1833]=[[Failed to get the process handle.]];
_tblErrorMessages[1900]=[[Could not open text file.]];
_tblErrorMessages[1901]=[[The text file is too large to be read.]];
_tblErrorMessages[1902]=[[Error, could not save text file.]];
_tblErrorMessages[2000]=[[Error, window handle is not valid.]];
_tblErrorMessages[2001]=[[Error, could not hide window.]];
_tblErrorMessages[2002]=[[Error, could not maximize window.]];
_tblErrorMessages[2003]=[[Error, could not minimize window.]];
_tblErrorMessages[2004]=[[Error, could not restore window.]];
_tblErrorMessages[2005]=[[Error, could not show window.]];
_tblErrorMessages[2006]=[[Error, could not load transparency map file.]];
_tblErrorMessages[2007]=[[Error, could not set window mask.]];
_tblErrorMessages[2100]=[[Error, could not eject drive, action not supported.]];
_tblErrorMessages[2101]=[[Error, could not calculate free space.]];
_tblErrorMessages[2102]=[[Error, could not calculate total size.]];
_tblErrorMessages[2103]=[[Error, could not calculate used space.]];
_tblErrorMessages[2104]=[[Failed to get volume information.]];
_tblErrorMessages[2200]=[[Could not create folder.]];
_tblErrorMessages[2201]=[[The specified folder does not exist.]];
_tblErrorMessages[2202]=[[The specified path does not point to a folder.]];
_tblErrorMessages[2203]=[[Could not delete folder.]];
_tblErrorMessages[2204]=[[Could not set the current folder.]];
_tblErrorMessages[2205]=[[The destination folder already exists.]];
_tblErrorMessages[2206]=[[The folder name contains invalid characters.]];
_tblErrorMessages[2207]=[[Could not delete base folder.]];
_tblErrorMessages[2300]=[[Could not create folder for shortcut.]];
_tblErrorMessages[2301]=[[Could not create the link for the shortcut.]];
_tblErrorMessages[2302]=[[Error, the shortcut description is longer then 250 characters.]];
_tblErrorMessages[2303]=[[Shortcut could not be deleted.]];
_tblErrorMessages[2304]=[[Unknown shell folder.]];
_tblErrorMessages[2305]=[[The folder returned is invalid.]];
_tblErrorMessages[2400]=[[Failed to load the specified DLL.]];
_tblErrorMessages[2401]=[[Failed to find the specified function within the DLL.]];
_tblErrorMessages[2500]=[[Failed to create the Internet session.]];
_tblErrorMessages[2501]=[[Failed to create the Internet connection.]];
_tblErrorMessages[2502]=[[Could not open request.]];
_tblErrorMessages[2503]=[[Send request failed.]];
_tblErrorMessages[2504]=[[Could not open the destination file for writing.]];
_tblErrorMessages[2505]=[[Invalid HTTP response from server.]];
_tblErrorMessages[2506]=[[An error occurred when downloading information from the server.]];
_tblErrorMessages[2507]=[[An error occurred while trying to write to the destination file.]];
_tblErrorMessages[2508]=[[The user has aborted the action.]];
_tblErrorMessages[2509]=[[An error occurred while trying to open an FTP file.]];
_tblErrorMessages[2510]=[[An error occurred when trying to write to memory. (Out of memory?)]];
_tblErrorMessages[2511]=[[An error occurred when trying to set the proxy username.]];
_tblErrorMessages[2512]=[[An error occurred when trying to set the proxy password.]];
_tblErrorMessages[2513]=[[The request could not be understood by the server. (Bad Syntax)]];
_tblErrorMessages[2514]=[[Access is forbidden.]];
_tblErrorMessages[2515]=[[The requested URL was not found on the server.]];
_tblErrorMessages[2516]=[[An internal server error has occurred.]];
_tblErrorMessages[2517]=[[The server is at full capacity.]];
_tblErrorMessages[2600]=[[Could not reenter the zip file.]];
_tblErrorMessages[2601]=[[Unexpected end of zip file.]];
_tblErrorMessages[2602]=[[Zip file structure error.]];
_tblErrorMessages[2603]=[[Out of memory.]];
_tblErrorMessages[2604]=[[Internal logic error.]];
_tblErrorMessages[2605]=[[Entry too large to split.]];
_tblErrorMessages[2606]=[[Invalid comment format.]];
_tblErrorMessages[2607]=[[Zip test failed or out of memory.]];
_tblErrorMessages[2608]=[[User cancelled.]];
_tblErrorMessages[2609]=[[An error occurred when using a temp file.]];
_tblErrorMessages[2610]=[[A read or seek error occurred.]];
_tblErrorMessages[2611]=[[No files were added to the zip file.]];
_tblErrorMessages[2612]=[[Missing or empty zip file.]];
_tblErrorMessages[2613]=[[Error writing to a file.]];
_tblErrorMessages[2614]=[[Couldn't open to write.]];
_tblErrorMessages[2615]=[[Bad control parameters.]];
_tblErrorMessages[2616]=[[Could not complete operation.]];
_tblErrorMessages[2617]=[[Could not open a specified file to read.]];
_tblErrorMessages[2618]=[[Media error. Disk not ready, hardware read/write error.]];
_tblErrorMessages[2619]=[[Bad Multi-Volume control parameters.]];
_tblErrorMessages[2620]=[[Improper usage of a Multi-Volume Zip File.]];
_tblErrorMessages[2621]=[[Unexpected end of zip file, the zip file may be corrupted.]];
_tblErrorMessages[2622]=[[The internal structure of the zip file is invalid.]];
_tblErrorMessages[2623]=[[Out of memory, not enough memory was available to complete the action.]];
_tblErrorMessages[2624]=[[The zip file could not be found.]];
_tblErrorMessages[2625]=[[There was nothing to extract in the unzip action.]];
_tblErrorMessages[2626]=[[An error occurred when trying to extract to the same volume.]];
_tblErrorMessages[2627]=[[The index specified in the zip file was out of bounds.]];
_tblErrorMessages[2628]=[[An error occurred when creating the output file.]];
_tblErrorMessages[2629]=[[An error occurred when opening the zip file. The zip file may be locked or unavailable.]];
_tblErrorMessages[2630]=[[An extracted file has an incorrect CRC value and may be corrupted.]];
_tblErrorMessages[2631]=[[The operation has been canceled.]];
_tblErrorMessages[2632]=[[A file was skipped during the extraction because it is encrypted and no password was specified, or the password was incorrect.]];
_tblErrorMessages[2633]=[[A file was skipped because it used an unknown compression format.]];
_tblErrorMessages[2634]=[[Bad or missing decrypt code, either no password was specified, or the password was incorrect..]];
_tblErrorMessages[2635]=[[Busy error, the zip file could not be entered.]];
_tblErrorMessages[2636]=[[Could not extract volume ID item.]];
_tblErrorMessages[2637]=[[A bad command structure was used when attempting to unzip the file.]];
_tblErrorMessages[2638]=[[The operation was canceled through an internal function.]];
_tblErrorMessages[2639]=[[One or more of the files was skipped during the extraction phase. Usually this is caused by an incorrect password.]];
_tblErrorMessages[2640]=[[The destination disk was full, and no more information could be written to it.]];
_tblErrorMessages[2641]=[[The destination folder could not be created.]];
_tblErrorMessages[2700]=[[Could not register window class to create splash dialog.]];
_tblErrorMessages[2701]=[[Could not create Flash splash dialog.]];
_tblErrorMessages[2702]=[[Could not create image splash dialog.]];
_tblErrorMessages[2703]=[[Could not create video splash dialog.]];
_tblErrorMessages[2800]=[[An error occurred getting the current page name. No current page.]];
_tblErrorMessages[2801]=[[Could not load value.]];
_tblErrorMessages[2802]=[[Could not save value.]];
_tblErrorMessages[2803]=[[Error, could not get applications window handle.]];
_tblErrorMessages[2804]=[[The specified icon file could not be found.]];
_tblErrorMessages[2805]=[[Failed to set the system tray icon.]];
_tblErrorMessages[2806]=[[The application does not contain a system tray icon.]];
_tblErrorMessages[2807]=[[Failed to set the system tray icon tooltip.]];
_tblErrorMessages[2900]=[[An internal error occurred resolving the specified function.]];
_tblErrorMessages[2901]=[[A runtime error occurred while calling the function.]];
_tblErrorMessages[2902]=[[A memory allocation error occurred while calling the function.]];
_tblErrorMessages[3000]=[[An invalid index has been specified. Indices must be greater than or equal to -1.]];
_tblErrorMessages[3001]=[[The specified path is longer then MAX_PATH,or 260 characters.]];
_tblErrorMessages[3300]=[[The specified math value is not valid for the given function.]];
_tblErrorMessages[3400]=[[The item could not be found in the tree.]];
_tblErrorMessages[3401]=[[An error occurred when trying to update the item in the tree.]];
_tblErrorMessages[3402]=[[An error occurred when trying to insert the item into the tree.]];
_tblErrorMessages[3403]=[[Error, the tree's window is not valid. This action needs a valid window to succeed.]];
_tblErrorMessages[3404]=[[An internal pointer error has occurred.]];
_tblErrorMessages[3405]=[[An error occurred when trying to expand the specified item.]];
_tblErrorMessages[4200]=[[Failed to load MSI.DLL. Windows Installer is not installed.]];
_tblErrorMessages[4201]=[[Failed to load function from MSI.DLL.]];
_tblErrorMessages[4203]=[[The user has cancelled the installation.]];
_tblErrorMessages[4204]=[[A fatal error occurred during the installation.]];
_tblErrorMessages[4205]=[[Installation suspended, incomplete.]];
_tblErrorMessages[4206]=[[Error unknown product.]];
_tblErrorMessages[4207]=[[Error unknown feature.]];
_tblErrorMessages[4208]=[[Error unknown component.]];
_tblErrorMessages[4209]=[[Error unknown property.]];
_tblErrorMessages[4210]=[[The handle is in an invalide state.]];
_tblErrorMessages[4211]=[[MSI configuration data is invalid.]];
_tblErrorMessages[4212]=[[The component qualifier is not present.]];
_tblErrorMessages[4213]=[[The installation source for this product is not available.]];
_tblErrorMessages[4214]=[[The product is uninstalled.]];
_tblErrorMessages[4215]=[[The SQL query syntax is invalid or unsupported.]];
_tblErrorMessages[4216]=[[The record field does not exist.]];
_tblErrorMessages[4217]=[[The Windows Installer service could not be accessed.]];
_tblErrorMessages[4218]=[[Error package version.]];
_tblErrorMessages[4219]=[[Another installation is already in progress.]];
_tblErrorMessages[4220]=[[This installation package could not be opened.]];
_tblErrorMessages[4221]=[[This installation package could not be opened, it appears to be invalid.]];
_tblErrorMessages[4222]=[[There was an error starting the Windows Installer service user interface.]];
_tblErrorMessages[4223]=[[There was an error opening installation log file.]];
_tblErrorMessages[4224]=[[This language of this installation package is not supported by your system.]];
_tblErrorMessages[4225]=[[This installation is forbidden by system policy.]];
_tblErrorMessages[4226]=[[The function could not be executed.]];
_tblErrorMessages[4227]=[[The function failed during execution.]];
_tblErrorMessages[4228]=[[An invalid or unknown table was specified.]];
_tblErrorMessages[4229]=[[The data supplied is the wrong type.]];
_tblErrorMessages[4230]=[[Data of this type is not supported.]];
_tblErrorMessages[4231]=[[The Windows Installer service failed to start.]];
_tblErrorMessages[4232]=[[The Temp folder is either full or inaccessible.]];
_tblErrorMessages[4233]=[[This installation package is not supported on this platform.]];
_tblErrorMessages[4234]=[[The install component is not used on this machine.]];
_tblErrorMessages[4235]=[[There was an error applying transforms.]];
_tblErrorMessages[4236]=[[This patch package could not be opened.]];
_tblErrorMessages[4237]=[[This patch package could not be opened, it appears to be invalid.]];
_tblErrorMessages[4238]=[[This patch package cannot be processed by the Windows Installer service, it is unsupported.]];
_tblErrorMessages[4239]=[[Another version of this product is already installed.]];
_tblErrorMessages[4240]=[[Invalid command line argument.]];
_tblErrorMessages[4241]=[[Installation from a Terminal Server client session is not permitted for the current user.]];
_tblErrorMessages[4242]=[[The installer has initiated a restart.]];
_tblErrorMessages[4243]=[[The installer cannot install the upgrade patch because the program being upgraded may be missing or the upgrade patch updates a different version of the program.]];
_tblErrorMessages[4244]=[[The patch package is not permitted by system policy.]];
_tblErrorMessages[4245]=[[One or more customizations are not permitted by system policy.]];
_tblErrorMessages[4246]=[[Windows Installer does not permit installation from a Remote Desktop Connection.]];
_tblErrorMessages[4247]=[[The patch package is not a removable patch package.]];
_tblErrorMessages[4248]=[[The patch could not be applied to this product. Unknown patch.]];
_tblErrorMessages[4249]=[[A valid sequence could not be found for the set of patches.]];
_tblErrorMessages[4250]=[[Patch removal was disallowed by policy.]];
_tblErrorMessages[4251]=[[The XML patch data is invalid.]];
_tblErrorMessages[4252]=[[Administrative user failed to apply patch for a per-user managed or a per-machine application that is in advertise state.]];
_tblErrorMessages[4253]=[[An invalid parameter has been passed to the function.]];
_tblErrorMessages[4254]=[[A buffer is too small to hold all of the data.]];
_tblErrorMessages[4255]=[[A restart is required to complete the install.]];
_tblErrorMessages[4256]=[[The MSI file is invalid, or does not contain a valid version of specific information.]];
_tblErrorMessages[4257]=[[The MSI file contains invalid data.]];
_tblErrorMessages[4258]=[[An unexpected error has occurred.]];
_tblErrorMessages[4259]=[[An invalid handle has been used.]];
_tblErrorMessages[4300]=[[An invalid line index was specified.]];
_tblErrorMessages[4301]=[[An error occurred while trying to retrieve a line of text from the RichText object.]];
_tblErrorMessages[4302]=[[Unable to open rich text (RTF) file for reading.]];
_tblErrorMessages[4303]=[[Unable to open rich text (RTF) file for writing.]];
_tblErrorMessages[4306]=[[Attempt to set character format of current selection in RichText object failed.]];
_tblErrorMessages[4307]=[[Attempt to set paragraph format of current selection in RichText object failed.]];
_tblErrorMessages[4400]=[[An error occurred when adding the slide to the SlideShow.]];
_tblErrorMessages[5000]=[[The specified dialog does not exist.]];
_tblErrorMessages[5001]=[[Error an application dialog is not visible.]];
_tblErrorMessages[5002]=[[No radiobutton in specified group.]];
_tblErrorMessages[5003]=[[Failed to create properties table.]];
_tblErrorMessages[5004]=[[Error, the specified dialog is already in use.]];
_tblErrorMessages[5005]=[[Error, could not get dialog window handle.]];
_tblErrorMessages[5006]=[[Error, cannot show a dialog with a status dialog visible.]];
_tblErrorMessages[5007]=[[Error, cannot close a dialog with a status dialog visible.]];
_tblErrorMessages[6001]=[[An error occurred while trying to iterate the services.]];
_tblErrorMessages[6002]=[[An error occurred while trying to query the services.]];
_tblErrorMessages[6003]=[[The service could not be found.]];
_tblErrorMessages[6004]=[[The continue command failed.]];
_tblErrorMessages[6005]=[[The stop command failed.]];
_tblErrorMessages[6006]=[[The start command failed.]];
_tblErrorMessages[6007]=[[The pause command failed.]];
_tblErrorMessages[6008]=[[The delete command failed.]];
_tblErrorMessages[6009]=[[The create command failed.]];
_tblErrorMessages[6010]=[[The handle to the specified service control manager database does not have access.]];
_tblErrorMessages[6011]=[[A circular service dependency was specified.]];
_tblErrorMessages[6012]=[[The display name already exists in the service control manager database either as a service name or as another display name.]];
_tblErrorMessages[6013]=[[The handle to the specified service control manager database is invalid.]];
_tblErrorMessages[6014]=[[The specified service name is invalid.]];
_tblErrorMessages[6015]=[[A parameter that was specified is invalid.]];
_tblErrorMessages[6016]=[[The user account name specified does not exist.]];
_tblErrorMessages[6017]=[[The specified service already exists in this database.]];
_tblErrorMessages[7000]=[[The QuickTime object's internal movie interface has not been attached.]];
_tblErrorMessages[7001]=[[The QuickTime object's window is not valid.]];
_tblErrorMessages[8000]=[[The PDF object's window is not valid.]];
_tblErrorMessages[9999]=[[Unknown error.]];
_tblErrorMessages[12400]=[[Grid operation failed.]];
_tblErrorMessages[12401]=[[Invalid grid window.]];
_tblErrorMessages[12402]=[[Invalid cell.]];
_tblErrorMessages[12403]=[[Invalid grid pointer.]];
_tblErrorMessages[12404]=[[Invalid grid delimiter.]];
_tblErrorMessages[34000]=[[String does not contain valid base-64 encoded data.]];
_tblErrorMessages[34001]=[[Error while attempting to decode base-64 encoded string (usually means string is corrupt - missing bytes in string?).]];
_tblErrorMessages[34002]=[[Invalid file header - not an Indigo Rose blowfish file.]];
_tblErrorMessages[34003]=[[Incompatible blowfish file. (The file has either been damaged or it uses an incompatible block padding scheme.)]];
_tblErrorMessages[37000]=[[Error loading XML file.]];
_tblErrorMessages[37001]=[[Error saving XML file.]];
_tblErrorMessages[37002]=[[No valid XML document loaded. (The document is empty or not well formed.)]];
_tblErrorMessages[37003]=[[The specified XML path is not valid or was not found.]];
_tblErrorMessages[37004]=[[An error occurred while trying to set the value.]];
_tblErrorMessages[37005]=[[An error occurred while trying to set the attribute.]];
_tblErrorMessages[37006]=[[Invalid attribute name. (Attribute names cannot contain spaces.)]];
_tblErrorMessages[37007]=[[The specified element could not be removed.]];
_tblErrorMessages[37008]=[[The specified attribute could not be removed.]];
_tblErrorMessages[37009]=[[There are no elements below the specified XML path.]];
_tblErrorMessages[37010]=[[The element at the specified XML path does not have any attributes.]];
_tblErrorMessages[37011]=[[An error occurred while trying to insert XML.]];
_tblErrorMessages[37012]=[[Invalid insertion mode.]];
_tblErrorMessages[77001]=[[Could not add item to the ComboBox.]];
_tblErrorMessages[77002]=[[An error occurred when trying to set the items data.]];
_tblErrorMessages[77003]=[[An error occurred when trying to delete the item from the ComboBox.]];
_tblErrorMessages[77004]=[[Error index is out of range.]];
_tblErrorMessages[77005]=[[An error occurred trying to get the item's text.]];
_tblErrorMessages[77006]=[[Could not insert item into the ComboBox.]];
_tblErrorMessages[77007]=[[An error occurred setting the items text.]];
_tblErrorMessages[77008]=[[An error occurred setting the current selection.]];

function print( ... )
	local args 
	for _, str in ipairs (arg) do
		if not args then 
			args = str 
		else
			args = args .. "\t" ..tostring(str)
		end
	end
	Dialog.Message("print", tostring(args))
end

ams = {}

function ams.getform( ... )
	local current = Application.GetCurrentDialog()
	if current == '' then current = Application.GetCurrentPage() end
	return current
end

function ams.getevent()
	local current = Application.GetCurrentDialog()

	if current == '' then 
		current = Application.GetCurrentPage() 
		if current == '' then
			current = "Project"
		end
	end

	local context = Debug.GetEventContext():gsub("->", ''):gsub(current, '')
	
	context = context:sub(3, context:len())
	return context
end

function voidf (...) end

load_thlog = function ( ... )
	
local self = {
   writelog  = true, full = false,
   debugmode = true,
   logfile   = "error.log",
   infolog   = string.format("[%s]", _VERSION)
}

function self.geterror(ERRMSG) --f)
   if self.full then
      level = 0
   else
      level = 9
   end

   ERRMSG = debug.traceback(ERRMSG, level)

   if ERRMSG:sub(#ERRMSG-15, #ERRMSG) == "stack traceback:" then
      ERRMSG = ERRMSG:gsub("\nstack traceback:", '')
   end

   return ERRMSG .. "\n\n"
end

function self.errorlog (ERRMSG)
   local ERRHEAD = "["..os.date("%c").."]"   

   if ERRMSG == "__NOREPORT__" then 
      return false 
   else
      ERRMSG = self.geterror(ERRMSG)
   end
   
   if not self.logfile or not type(self.logfile) == "string" then
      self.logfile = "errors.log"
   end  
   
   if self.infolog then
      ERRHEAD = ERRHEAD .. "\t" .. self.infolog
   end

   if self.conERRMSG then
      local _, conERRMSG = pcall(self.conERRMSG)
      if conERRMSG then
         ERRMSG = conERRMSG .. "\n" .. ERRMSG
      end
   end
  
   ERRMSG = ERRHEAD .. "\n"..ERRMSG

   if self.debugmode then
      io.stderr:write(ERRMSG)
      -- AMS
      Dialog.Message("errorlog", ERRMSG, 0, 48)
   end
   
   if self.logfile then
      local file = io.open(self.logfile, "a+")
      
      if not file then
         file = io.output(self.logfile)
      end
      
      file:setvbuf("no")
      file:write(ERRMSG)
      file:close()
   end 
end

setmetatable(self,  {
      __call = function ( self, ... )
         self.errorlog(...)
      end
})
	return self
end

errorlog = load_thlog()
errorlog.infolog = string.format("[%s %s]", _IR_ProductID, _VERSION)

_AMSEvents = { 
	"On Audio", 
	"On Cell ",
	"On Changed", 
	"On Check", 
	"On Char",
	"On Click",
	"On Close",
	"On Double-Click",
	"On EditLabel",
	"On Enter",
	"On Error",
	"On Expanded",
	"On Finish",
	"On Finished",
	"On FlashCall",
	"On Focus",
	"On FSCommand",
	"On Hyperlink",
	"On Key",
	"On Leave",
	"On Link",
	"On Loaded",
	"On Menu",
	"On Mouse Button",
	"On Mouse Button Down",
	"On Mouse Button Up",
	"On Mouse Move",
	"On Mouse Wheel",
	"On Movie End",
	"On Navigate",
	"On Pause",
	"On Play",
	"On Preload",
	"On Rate Change",
	"On Right-Click",
	"On Show",
	"On Size",
	"On Select",
	"On Selection Changed",
	"On Shutdown",
	"On Slide Changed",
	"On Startup",
	"On Stop",
	"On Timer",

	--- "New" Events:
	"OnOver",
	"OnSetFocus",
}

Page.Events = _AMSEvents
--[[ {
	"On Preload",
	"On Show",
	"On Close",
	"On Timer",
	"On Audio",
	"On Size",
	"On Menu",
	"On Key",
	"On MouseButton",
	"On MouseMove",
	"On MouseWheel"
}]]

DialogEx.Events = Page.Events


_AMSObject = {}

_AMSObject.Events = _AMSEvents 

--[[{
	"On Click",
	"On Enter",
	"On Leave",
	
	"On SetFocus",
	"On Char", -- Input
	"On Key",  -- Input, ListBox
	"On Over", -- OnEnter -- Paragraph

	"On Double-Click", -- (Casi Todos)
	"On Select",	   -- ListBox
	"On Check",		   -- ListBox
}]]

PageOnPreloadScript = [[
	if not _G[this.."_loaded"] then
		_G[this.."_WndHandle"] = Application.GetWndHandle()
		
		if Page.EnumerateObjects() then
			for i, ObjName in pairs(Page.EnumerateObjects())do
				--_G[ObjName] = {Name = ObjName}
				for i, EventName in pairs(_AMSObject.Events) do
					if not _G[ObjName.."_"..EventName:gsub(' ', ''):gsub('-', '')] then
						_G[ObjName.."_"..EventName:gsub(' ', ''):gsub('-', '')] = voidf
					end
					if EventName == "On Key" then
						Page.SetObjectScript(ObjName, EventName, Page.GetObjectScript(ObjName, EventName).." "..ObjOnKeyEventScript);
					elseif EventName == "On Char" then
						Page.SetObjectScript(ObjName, EventName, Page.GetObjectScript(ObjName, EventName).." "..ObjOnCharEventScript);
					else
						Page.SetObjectScript(ObjName, EventName, Page.GetObjectScript(ObjName, EventName).." "..ObjEventScript);
					end
				end
			end
		end
		_G[this.."_loaded"] = true
	end
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this)
	if not exc then
		errorlog(msg)
	end
]]

PageOnTimerEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this, e_ID)
	if not exc then
		errorlog(msg)
	end
]]

PageOnAudioEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this, e_Channel, e_State)
	if not exc then
		errorlog(msg)
	end
]]

PageOnSizeEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this, e_WindowWidth, e_WindowHeight, e_PageWidth, e_PageHeight, e_Type)
	if not exc then
		errorlog(msg)
	end
]]

PageOnMenuEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this, e_ID, e_ItemInfo)
	if not exc then
		errorlog(msg)
	end
]]

PageOnKeyEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this, e_Key, e_Modifiers)
	if not exc then
		errorlog(msg)
	end
]]

PageOnMouseButtonEventScript = [[
	if not this then this = Application.GetCurrentPage() end
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this, e_Type, e_X, e_Y)
	if not exc then
		errorlog(msg)
	end
]]

PageOnMouseMoveEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this, e_X, e_Y)
	if not exc then
		errorlog(msg)
	end
]]

PageOnMouseWheelEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this, e_Flags, e_Delta, e_X, e_Y)
	if not exc then
		errorlog(msg)
	end
]]

--- ....

PageEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this)
	if not exc then
		errorlog(msg)
	end
]]

DialogOnPreloadScript = [[
	_G[this.."_WndHandle"] = DialogEx.GetWndHandle()
	
	if not _G[this.."_loaded"] then
		
		if DialogEx.EnumerateObjects() then
			for i, ObjName in pairs(DialogEx.EnumerateObjects())do
				for i, EventName in pairs(_AMSObject.Events) do
					if  not _G[ObjName.."_"..EventName:gsub(' ', ''):gsub('-', '')] then
						_G[ObjName.."_"..EventName:gsub(' ', ''):gsub('-', '')] = voidf
					end
					
					if EventName == "On Double-Click" then
						--Dialog.Message('', ObjName.."_"..EventName:gsub(' ', ''):gsub('-', ''))
					end

					if EventName == "On Key" then
						DialogEx.SetObjectScript(ObjName, EventName, DialogEx.GetObjectScript(ObjName, EventName).." "..ObjOnKeyEventScript);
					elseif EventName == "On Char" then
						DialogEx.SetObjectScript(ObjName, EventName, DialogEx.GetObjectScript(ObjName, EventName).." "..ObjOnCharEventScript);
					else
						DialogEx.SetObjectScript(ObjName, EventName, DialogEx.GetObjectScript(ObjName, EventName).." "..ObjEventScript);
					end

				end
			end
		end
		_G[this.."_loaded"] = true
	end

	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(' ', '')], this)
	if not exc then
		errorlog(msg)
	end
]]

DialogEventScript = PageEventScript
DialogOnTimerEventScript = PageOnTimerEventScript
DialogOnKeyEventScript = PageOnKeyEventScript
DialogOnSizeEventScript = PageOnKeyEventScript

ObjOnKeyEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(this, ''):gsub(' ', '')], this, e_Key, e_Modifiers)
	if not exc then
		errorlog(msg)
	end
]]

ObjOnCharEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(this, ''):gsub(' ', '')], this, e_Char, e_Modifiers)
	if not exc then
		errorlog(msg)
	end
]]

ObjEventScript = [[
	exc, msg = pcall(_G[this..'_'..ams.getevent():gsub(this, ''):gsub(' ', ''):gsub('-', '')], this)
	if not exc then
		errorlog(msg)
	end
]]

voidf = function()end

if Application.GetPages() then
	for i, PageName in pairs(Application.GetPages()) do
		for i, EventName in pairs (Page.Events) do
			
			_G[PageName.."_"..EventName:gsub(' ', '')] = voidf
			
			if EventName == "On Preload" then
				Application.SetPageScript(PageName, EventName, PageOnPreloadScript);
			elseif EventName == "On Key" then
				Application.SetPageScript(PageName, EventName, PageOnKeyEventScript);
			elseif EventName == "On Timer" then
				Application.SetPageScript(PageName, EventName, PageOnTimerEventScript);
			elseif EventName == "On Audio" then
				Application.SetPageScript(PageName, EventName, PageOnAudioEventScript);
			elseif EventName == "On Size" then
				Application.SetPageScript(PageName, EventName, PageOnSizeEventScript);
			elseif EventName == "On Menu" then
				Application.SetPageScript(PageName, EventName, PageOnMenuEventScript);
			elseif EventName == "On Mouse Button" then
				Application.SetPageScript(PageName, EventName, PageOnMouseButtonEventScript );
			elseif EventName == "On Mouse Wheel" then
				Application.SetPageScript(PageName, EventName, PageOnMouseWheelEventScript);
			elseif EventName == "On Mouse Move" then
				Application.SetPageScript(PageName, EventName, PageOnMouseMoveEventScript);
			else
				Application.SetPageScript(PageName, EventName, Application.GetPageScript (PageName, EventName).." "..PageEventScript);
			end
		end
	end
end

if Application.GetDialogs() then
	for i, DialogName in pairs(Application.GetDialogs()) do
		for i, EventName in pairs (DialogEx.Events) do
			_G[DialogName.."_"..EventName:gsub(' ', '')] = voidf
			
			if EventName == "On Preload" then
				Application.SetDialogScript(DialogName, EventName, DialogOnPreloadScript);
			elseif EventName == "On Size" then
				Application.SetDialogScript(DialogName, EventName, DialogOnSizeEventScript);
			elseif EventName == "On Key" then
				Application.SetDialogScript(DialogName, EventName, DialogOnKeyEventScript);
			elseif EventName == "On Timer" then
				Application.SetDialogScript(DialogName, EventName, DialogOnTimerEventScript);
			else
				Application.SetDialogScript(DialogName, EventName, Application.GetDialogScript (DialogName, EventName).." "..DialogEventScript);
			end
		end
	end
end
Instrucciones de instalaci�n:

Copie el archivo _error_messages.lua en la Data\Includes que se encuentra en la carpeta de instalaci�n de AMS8.

Usualmente "C:\Program Files\AutoPlay Media Studio 8 Trial\Data\Includes"

�Bugs, Sugerencias, Quejas?
amsspecialist.com
thedary.tumblr.com
thdkano@gmail.com

enjoy!